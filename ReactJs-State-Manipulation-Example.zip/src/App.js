import React, { Component } from 'react';  
import Person from './Person/Person.js';
import './App.css';
class App extends Component {
  state = {
    Person : [{Name: 'Yojith', Age : 7},
    {Name: 'Sujith', Age : 5},
    {Name: 'Ranjith', Age : 9}],
    hidePersons : true
  }
  switchNamesHandler = () => {
    this.setState({
      Person : [{Name: 'YOJITH', Age : 7},
    {Name: 'SUJITH', Age : 5},
    {Name: 'RANJITH', Age : 9}]
    })
    }
  taggleHandler = () => {
    const getHideValue = this.state.hidePersons;
    this.setState({
      hidePersons : !getHideValue
    })
  }

deletePersonHandler = (personIndex) =>{
  const person = this.state.Person;
  person.splice(personIndex,1);
  this.setState({
    Person: person
  })
}

updatePersonHadler = (personIndex) =>{
  const person=this.state.Person;
  person[personIndex].Name = 'Modified';
  this.setState({
    Person : person
  })
}

reloadPersonHandler = () => {
  this.setState({
     Person : [{Name: 'Yojith', Age : 7},
    {Name: 'Sujith', Age : 5},
    {Name: 'Ranjith', Age : 9}]
  })
}

  render() {
    let persons = null;
    if(this.state.hidePersons)
      persons = (
        this.state.Person.map((person,index) =>
        <Person 
          Name = {person.Name} 
          Age = {person.Age} 
          DeleteClick = {()=>this.deletePersonHandler(index)}
          UpdateClick={()=>this.updatePersonHadler(index)}/>
        )        
    );

    return (
      <div>
        <h1>ReactJS, State example</h1>
        <p>Delete, update and reaload state object using simple example</p>
        <button onClick ={this.switchNamesHandler}>Switch Names</button>
        <button onClick = {this.taggleHandler}>Taggle persons</button>
        <button onClick = {this.reloadPersonHandler}>Reload Page</button>
        {persons}
      </div>
    );
  }
}
export default App;