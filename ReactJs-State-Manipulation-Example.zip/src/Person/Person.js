import React, {Component} from 'react';

const person = (props) => {
    return (
    <div className='Component'>
        <h1>Name: {props.Name}</h1>
        <h2>Age:  {props.Age}.</h2>
        <button onClick = {props.DeleteClick}>Delete Person</button> 
        <button onClick = {props.UpdateClick}>Update Name</button>
    </div> );
}
export default person;